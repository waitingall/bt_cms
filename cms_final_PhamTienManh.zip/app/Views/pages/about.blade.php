<?php
@extends('layouts.sidebar')
@section('content')
    i am the about page
@stop
