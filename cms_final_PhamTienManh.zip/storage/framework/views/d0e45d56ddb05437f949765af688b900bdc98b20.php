    
		
		
<div class="type-16">
    <div id="main-content">
        <section class="content-area">
            <div class="container site-content">
                <div class="row">
                    <main id="main" class="site-main col-sm-12 full-width">
                        <article id="post-1668" class="post-1668 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div id="pl-1668">
                                    <div class="panel-grid" id="pg-1668-0">
                                        <div class="panel-grid-cell" id="pgc-1668-0-0">
                                            <div class="so-panel widget widget_gallery panel-first-child panel-last-child" id="panel-1668-0-0-0" data-index="0">
                                                <div class="thim-widget-gallery thim-widget-gallery-base">
                                                    <div class="wrapper-filter-controls">
                                                        <div class="filter-controls">
                                                            <a class="filter active">All</a>
                                                            <a class="filter" href="javascript:;" data-filter=".filter-gallery-1664">COFFEE SHOP</a><a class="filter" href="javascript:;" data-filter=".filter-gallery-1661">GOURMET</a><a class="filter" href="javascript:;" data-filter=".filter-gallery-1666">RECIPES</a> </div>
                                                    </div>
                                                    <div class="wrapper-gallery-filter grid row">
                                                        <?php foreach($gallerytuananh as $gallerytuananhs) { ?>
                                                        <div class="item-photo element col-sm-3 col-xs-6 filter-gallery-1664">
                                                            <div class="inner">
                                                                <a class="fancybox" data-fancybox-group="gallery" href="<?php echo $gallerytuananhs->images ?>"><img src="<?php echo $gallerytuananhs->images ?>" alt="Restaurant" title="Restaurant" />
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <?php } ?>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </article>

                    </main>
                </div>
            </div>
        </section>
    </div>