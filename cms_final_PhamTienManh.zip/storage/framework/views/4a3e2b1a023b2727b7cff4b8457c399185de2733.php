
	<?php echo $__env->make('common/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="main">
		<div class="main_content">
			<?php echo $__env->make('common/thong', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/pho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/thien', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/quang', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/manh', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/hung', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/tuananh', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/sang', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common/hai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		
	</div>
<?php echo $__env->make('common/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
