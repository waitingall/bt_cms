Route::get('blade', function () {
    return view('page',array('name' => 'The Raven'));
});