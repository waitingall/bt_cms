<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="style.css" rel="stylesheet" type="text/css" />
	<title>My First Page in Laravel</title>
</head>
<body>



	<div class="main">
	
		
		<div class="main_content">

dddddddddd
		</div>
	
	</div>



